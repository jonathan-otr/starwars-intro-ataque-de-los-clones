Para visualizar el intro solo dar click en la pantalla de inicio, al terminar el intro se reanudara
 la intro volviendo a ser necesario el click para comenzar.

La informacion del intro se consigue en la pagina (https://starwars.fandom.com/es/wiki/Texto_de_apertura), se tomo
el texto del capitulo 2 el ataque de los clones.


Lenguajes de programación usados:
 -CSS (animación y tranformación del texto)
 -HTML (conseguir el audio original de la saga)
 -JavaScript (sincronizar el audio con los eventos)
