StarWars = (function() {

  function StarWars(args) {
    this.el = $(args.el);
    this.audio = this.el.find('audio').get(0);
    this.start = this.el.find('.start');
    this.iniciar = this.el.find('#iniciar');
    this.reiniciar = this.el.find('#reiniciar');
    this.animation = this.el.find('.animation');
    this.reset();



    this.iniciar.bind('click', $.proxy(function() {
      this.start.hide();
      this.audio.play();
      this.el.append(this.animation);
    }, this));

    this.reiniciar.bind('click', $.proxy(function() {
      this.audio.currentTime = 0;
      this.reset();

    }, this));



    $(this.audio).bind('ended', $.proxy(function() {
      this.audio.currentTime = 0;
      this.reset();
    }, this));
  }

  StarWars.prototype.reset = function() {
    this.start.show();
    this.cloned = this.animation.clone(true);
    this.animation.remove();
    this.animation = this.cloned;
  };

  return StarWars;
})();

new StarWars({
  el : '.starwars'
});
